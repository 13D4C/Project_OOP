package project;
public interface Showable {
    public default void show(){
        
    }
}
