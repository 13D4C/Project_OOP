package project;

public class Employee extends User {
    public Employee(String username, String password, String id, String role) {
        super(username, password, id, role);
    }
}
