package project;

public class UserDatabase {
    public static String key;
    public static User user;
}
