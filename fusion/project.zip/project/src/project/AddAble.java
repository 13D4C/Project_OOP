package project;

public interface AddAble {
    public void addNew();
}
