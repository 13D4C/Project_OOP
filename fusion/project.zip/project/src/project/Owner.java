package project;

public class Owner extends User {
    public Owner(String username, String password, String id, String role) {
        super(username, password, id, role);
    }
}
